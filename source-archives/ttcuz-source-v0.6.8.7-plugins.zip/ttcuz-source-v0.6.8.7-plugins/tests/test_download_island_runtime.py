"""Execute island size interpolation, reversals, cleanup and task rendering."""

import pathlib, tempfile, subprocess, shutil, unittest
from test_screen_runtime import STUBS as BASE

ROOT = pathlib.Path(__file__).resolve().parents[1]


class IslandRuntimeTest(unittest.TestCase):
    @unittest.skipUnless(shutil.which("javac") and shutil.which("java"), "JDK required")
    def test_expansion_reversal_and_cleanup(self):
        with tempfile.TemporaryDirectory() as d:
            w = pathlib.Path(d)
            sources = dict(BASE)
            sources["android/view/View.java"] = sources["android/view/View.java"].replace(
                "public void setAlpha(float v){}",
                "public float alpha=1;public void setAlpha(float v){alpha=v;}public float getAlpha(){return alpha;}public void setTranslationY(float v){}",
            )
            sources["android/view/View.java"] = sources["android/view/View.java"].replace(
                "public static final int VISIBLE=0;",
                "public static final int VISIBLE=0,GONE=8;public void setVisibility(int n){visibility=n;}",
            )
            sources["android/widget/LinearLayout.java"] = sources[
                "android/widget/LinearLayout.java"
            ].replace(
                "public LayoutParams(int w,int h){super(w,h);}",
                "public LayoutParams(int w,int h){super(w,h);}public LayoutParams(int w,int h,float weight){super(w,h);}",
            )
            sources["android/view/ViewGroup.java"] = sources["android/view/ViewGroup.java"].replace(
                "public void removeView",
                "public void removeAllViews(){children.clear();}public void addView(View v){addView(v,new LayoutParams(-1,-2));}public void removeView",
            )
            sources["android/widget/TextView.java"] = sources[
                "android/widget/TextView.java"
            ].replace(
                "public String text;",
                "public String text;public String getText(){return text;}public void setIncludeFontPadding(boolean v){}public void setMaxLines(int n){}public void setMinHeight(int n){}",
            )
            sources["android/widget/ProgressBar.java"] = sources[
                "android/widget/ProgressBar.java"
            ].replace(
                "public void setMax",
                "public void setProgressTintList(Object c){}public void setMax",
            )
            sources["android/widget/ScrollView.java"] = (
                "package android.widget;public class ScrollView extends android.view.ViewGroup {public ScrollView(android.content.Context c){super(c);}public void setFillViewport(boolean b){}}"
            )
            sources["android/animation/Animator.java"] = (
                "package android.animation;public class Animator{}"
            )
            sources["android/animation/AnimatorListenerAdapter.java"] = (
                "package android.animation;public class AnimatorListenerAdapter {public void onAnimationCancel(Animator a){}public void onAnimationEnd(Animator a){}}"
            )
            sources["android/animation/ValueAnimator.java"] = (
                """package android.animation;public class ValueAnimator extends Animator {public static ValueAnimator last;public long duration;float value;AnimatorUpdateListener update;AnimatorListenerAdapter listener;public interface AnimatorUpdateListener {void onAnimationUpdate(ValueAnimator a);}public static ValueAnimator ofFloat(float a,float b){return last=new ValueAnimator();}public void setDuration(long n){duration=n;}public void setInterpolator(Object o){}public void addUpdateListener(AnimatorUpdateListener l){update=l;}public Object getAnimatedValue(){return value;}public void addListener(AnimatorListenerAdapter l){listener=l;}public void start(){}public void cancel(){if(listener!=null)listener.onAnimationCancel(this);}public void step(float t){value=t;update.onAnimationUpdate(this);if(t==1&&listener!=null)listener.onAnimationEnd(this);}}"""
            )
            sources["android/widget/ProgressBar.java"] = sources[
                "android/widget/ProgressBar.java"
            ].replace(
                "public void setIndeterminate(boolean b)",
                "public boolean isIndeterminate(){return false;}public void setIndeterminate(boolean b)",
            )
            sources["cat/ttcuz/framework/Screen.java"] = (
                "package cat.ttcuz.framework;class Screen {static void tasksCollapsed(){}}"
            )
            sources["cat/ttcuz/framework/DownloadTasks.java"] = (
                """package cat.ttcuz.framework;class DownloadTasks {static class Task {String key="apk",label="Обновление",origin="Мод",owner="@alice",state="Загрузка";int percent=30;boolean cancel=true,retry=false;}static boolean empty;static java.util.List<Task> snapshot(){return empty?java.util.Collections.emptyList():java.util.Arrays.asList(new Task());}static void cancel(String key){}static void retry(String key){}}"""
            )
            for name in ("DownloadIsland", "DownloadMorph"):
                sources["cat/ttcuz/framework/" + name + ".java"] = (
                    ROOT / ("inject/java/cat/ttcuz/framework/" + name + ".java")
                ).read_text(encoding="utf-8")
            sources[
                "cat/ttcuz/framework/IslandHarness.java"
            ] = """package cat.ttcuz.framework;public class IslandHarness {static void check(boolean b,String s){if(!b)throw new AssertionError(s);}public static void main(String[] args){android.app.Activity a=new android.app.Activity();android.app.Dialog d=new android.app.Dialog(a);d.show();d.window.params.width=260;d.window.params.height=-2;DownloadMark mark=new DownloadMark(a,0);DownloadIsland island=new DownloadIsland(a,d,mark);island.toggle();android.animation.ValueAnimator first=android.animation.ValueAnimator.last;check(first.duration==340,"motion duration");first.step(.5f);check(d.window.params.width==290&&d.window.params.height>50,"midpoint interpolated");int width=d.window.params.width,height=d.window.params.height;island.toggle();android.animation.ValueAnimator closing=android.animation.ValueAnimator.last;closing.step(0);check(d.window.params.width==width&&d.window.params.height==height,"reversal preserves size");island.toggle();check(mark.children.size()==1,"reopening retains one list");android.animation.ValueAnimator.last.step(1);check(d.window.params.width==320&&island.expanded(),"expanded state");island.collapse(null);android.animation.ValueAnimator.last.step(1);check(mark.children.isEmpty()&&mark.pending.isEmpty(),"collapse removes rows and polling");DownloadTasks.empty=true;island.toggle();check(!mark.children.isEmpty(),"empty tasks view opens");island.dispose();check(mark.pending.isEmpty(),"dispose removes polling");}}
"""
            for n, s in sources.items():
                p = w / n
                p.parent.mkdir(parents=True, exist_ok=True)
                p.write_text(s, encoding="utf-8")
            run = subprocess.run(
                ["javac", "-source", "8", "-target", "8", "-encoding", "UTF-8", "-d", d]
                + [str(w / n) for n in sources],
                capture_output=True,
                text=True,
            )
            self.assertEqual(0, run.returncode, run.stderr)
            run = subprocess.run(
                ["java", "-cp", d, "cat.ttcuz.framework.IslandHarness"],
                capture_output=True,
                text=True,
            )
            self.assertEqual(0, run.returncode, run.stderr)
