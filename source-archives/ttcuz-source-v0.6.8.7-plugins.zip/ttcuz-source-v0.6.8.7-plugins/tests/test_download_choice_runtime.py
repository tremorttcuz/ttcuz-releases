import pathlib, shutil, subprocess, tempfile, unittest

ROOT = pathlib.Path(__file__).resolve().parents[1]
STUBS = {
    "android/content/Context.java": "package android.content; public class Context {}",
    "android/view/View.java": """package android.view; public class View {public static final int VISIBLE=0;public View parent;public CharSequence desc;public OnClickListener click;public Runnable pending;public interface OnClickListener{void onClick(View v);} public View getRootView(){return parent==null?this:parent.getRootView();}public Object getParent(){return parent;}public CharSequence getContentDescription(){return desc;}public boolean hasOnClickListeners(){return click!=null;}public boolean isClickable(){return click!=null;}public void setOnClickListener(OnClickListener c){click=c;} public android.content.Context getContext(){return new android.content.Context();}public void post(Runnable r){pending=r;}public void postDelayed(Runnable r,long d){}public int getVisibility(){return VISIBLE;}public void getLocationOnScreen(int[] p){}public int getWidth(){return parent==null?400:100;}public int getHeight(){return 50;}}""",
    "android/view/ViewGroup.java": "package android.view;public class ViewGroup extends View{public java.util.List<View> children=new java.util.ArrayList<>();public void add(View v){children.add(v);v.parent=this;}public int getChildCount(){return children.size();}public View getChildAt(int i){return children.get(i);}}",
    "android/widget/TextView.java": "package android.widget;public class TextView extends android.view.View{public CharSequence text;public CharSequence getText(){return text;}}",
    "android/view/Window.java": "package android.view;public class Window{public interface Callback{}public View root;public Callback callback;public View getDecorView(){return root;}public Callback getCallback(){return callback;}public void setCallback(Callback c){callback=c;}}",
    "android/view/MotionEvent.java": "package android.view;public class MotionEvent{public static final int ACTION_DOWN=0,ACTION_UP=1,ACTION_CANCEL=3,ACTION_MOVE=2,ACTION_POINTER_DOWN=5;public int getActionMasked(){return 0;}public float getRawX(){return 0;}public float getRawY(){return 0;}public long getEventTime(){return 0;}public static MotionEvent obtain(MotionEvent e){return e;}public void setAction(int a){}public void recycle(){}}",
    "android/view/ViewConfiguration.java": "package android.view;public class ViewConfiguration{public static ViewConfiguration get(android.content.Context c){return new ViewConfiguration();}public int getScaledTouchSlop(){return 8;}}",
    "android/graphics/Rect.java": "package android.graphics;public class Rect{public Rect(int l,int t,int r,int b){}public boolean contains(int x,int y){return false;}}",
    "android/app/Dialog.java": "package android.app;public class Dialog{public android.view.Window window=new android.view.Window();public int shows,dismisses;public void show(){shows++;}public boolean isShowing(){return true;}public void dismiss(){dismisses++;}public android.view.Window getWindow(){return window;}public android.content.Context getContext(){return new android.content.Context();}}",
    "cat/ttcuz/framework/Diary.java": "package cat.ttcuz.framework;class Diary{static void note(String s){}}",
    "cat/ttcuz/framework/VideoActions.java": "package cat.ttcuz.framework;class VideoActions{static Object post,chosen;static Object downloadPost(android.content.Context c){return post;}static void chooseDownload(android.content.Context c,Object p){chosen=p;}}",
    "cat/ttcuz/framework/ChoiceHarness.java": """package cat.ttcuz.framework;import android.view.*;import android.widget.*;import android.app.*;public class ChoiceHarness{static void check(boolean b){if(!b)throw new AssertionError();}public static class Payload{public Object LL;}public static class Component{public Payload LLJJJJLIIL;}public static void main(String[] a){Component c=new Component();c.LLJJJJLIIL=new Payload();Object first=new Object(),second=new Object();c.LLJJJJLIIL.LL=first;check(NativeRead.item(c)==first);Dialog d=new Dialog();ViewGroup root=new ViewGroup();d.window.root=root;ViewGroup button=new ViewGroup();button.setOnClickListener(v->{throw new AssertionError("native save should be replaced");});TextView label=new TextView();label.text="Сохранить видео";button.add(label);root.add(button);TextView unrelated=new TextView();unrelated.text="Сохранить";int[] clicks={0};unrelated.setOnClickListener(v->clicks[0]++);root.add(unrelated);VideoActions.post=first;DownloadChoice.show(d);VideoActions.post=second;root.pending.run();button.click.onClick(button);check(VideoActions.chosen==first&&d.dismisses==1);DownloadChoice.show(d);root.pending.run();button.click.onClick(button);check(VideoActions.chosen==second&&d.dismisses==2);unrelated.click.onClick(unrelated);check(clicks[0]==1);check(!DownloadChoice.saveLabel("сохранить профиль"));for(String yes:new String[]{"Скачать","Download","Скачать фото","Сохранить видео"})check(DownloadChoice.saveLabel(yes));for(String no:new String[]{"Сохранить","Save","Скачать приложение","Save image","Добавить в историю"})check(!DownloadChoice.saveLabel(no));VideoActions.post=null;root.pending=null;DownloadChoice.show(d);check(root.pending==null&&d.shows==3);}}""",
}


class DownloadChoiceRuntimeTest(unittest.TestCase):
    @unittest.skipUnless(shutil.which("java") and shutil.which("javac"), "JDK required")
    def test_native_model_and_recycled_save_dialog(self):
        with tempfile.TemporaryDirectory() as tmp:
            work = pathlib.Path(tmp)
            sources = dict(STUBS)
            for name in ("DownloadChoice", "NativeRead"):
                sources["cat/ttcuz/framework/" + name + ".java"] = (
                    ROOT / "inject/java/cat/ttcuz/framework" / (name + ".java")
                ).read_text(encoding="utf-8")
            for name, value in sources.items():
                target = work / name
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_text(value, encoding="utf-8")
            result = subprocess.run(
                ["javac", "-source", "8", "-target", "8", "-encoding", "UTF-8", "-d", str(work)]
                + [str(work / name) for name in sources],
                capture_output=True,
                text=True,
            )
            self.assertEqual(0, result.returncode, result.stderr)
            result = subprocess.run(
                ["java", "-cp", str(work), "cat.ttcuz.framework.ChoiceHarness"],
                capture_output=True,
                text=True,
            )
            self.assertEqual(0, result.returncode, result.stderr)
