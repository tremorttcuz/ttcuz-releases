"""Run the actual narrow contrast guard with native-like view hierarchies."""

import unittest
from pathlib import Path
import test_settings_safety_runtime as safety

ROOT = Path(__file__).resolve().parents[1]


class UiContrastRuntimeTest(unittest.TestCase):
    def test_dark_controls_light_restoration_and_media_exclusion(self):
        sources = {
            "android/content/res/ColorStateList.java": "package android.content.res;public class ColorStateList {int c;public int[] colours;public int[][] states;public ColorStateList(int c){this.c=c;}public ColorStateList(int[][] s,int[] a){states=s;colours=a;c=a[a.length-1];}public static ColorStateList valueOf(int c){return new ColorStateList(c);}public boolean isStateful(){return colours!=null && colours.length>1;}public int[][] getStates(){return states;}public int[] getColors(){return colours;}public int getDefaultColor(){return c;}public int getColorForState(int[] s,int d){return c;}}",
            "android/graphics/drawable/Drawable.java": "package android.graphics.drawable;public class Drawable {public Drawable getCurrent(){return this;}}",
            "android/graphics/drawable/ColorDrawable.java": "package android.graphics.drawable;public class ColorDrawable extends Drawable {int c;public ColorDrawable(int c){this.c=c;}public int getColor(){return c;}}",
            "android/graphics/drawable/GradientDrawable.java": "package android.graphics.drawable;public class GradientDrawable extends Drawable {public android.content.res.ColorStateList getColor(){return null;}}",
            "android/os/Build.java": "package android.os;public class Build {public static class VERSION {public static int SDK_INT=29;}}",
            "android/view/View.java": """package android.view;import android.graphics.drawable.*;import android.content.res.*;public class View {public int id;public View parent;public Drawable bg;public ColorStateList tint;public java.util.Map<Integer,Object> tags=new java.util.HashMap<>();public java.util.List<Runnable> tasks=new java.util.ArrayList<>();public int getId(){return id;}public View getParent(){return parent;}public Drawable getBackground(){return bg;}public ColorStateList getBackgroundTintList(){return tint;}public int[] getDrawableState(){return new int[0];}public Object getTag(int k){return tags.get(k);}public void setTag(int k,Object v){tags.put(k,v);}public interface OnAttachStateChangeListener {void onViewAttachedToWindow(View v);void onViewDetachedFromWindow(View v);}public java.util.List<OnAttachStateChangeListener> listeners=new java.util.ArrayList<>();public void addOnAttachStateChangeListener(OnAttachStateChangeListener l){listeners.add(l);}public void removeOnAttachStateChangeListener(OnAttachStateChangeListener l){listeners.remove(l);}public boolean post(Runnable r){tasks.add(r);return true;}}""",
            "android/view/ViewGroup.java": "package android.view;public class ViewGroup extends View {public java.util.List<View> children=new java.util.ArrayList<>();public void add(View v){children.add(v);v.parent=this;}public int getChildCount(){return children.size();}public View getChildAt(int i){return children.get(i);}}",
            "android/widget/TextView.java": 'package android.widget;import android.view.*;import android.content.res.*;public class TextView extends View {public String text="";public ColorStateList colours=new ColorStateList(0xff000000);public int writes;public CharSequence getText(){return text;}public int getCurrentTextColor(){return colours.getDefaultColor();}public ColorStateList getTextColors(){return colours;}public void setTextColor(int c){writes++;colours=new ColorStateList(c);}public void setTextColor(ColorStateList c){writes++;colours=c;}}',
            "com/bytedance/tux/icon/TuxIconView.java": "package com.bytedance.tux.icon;public class TuxIconView extends android.view.View {public Object LL;public int colour,writes;public void setTintColor(int c){colour=c;writes++;}}",
            "cat/ttcuz/framework/AppearanceColors.java": 'package cat.ttcuz.framework;class AppearanceColors {static final String TEXT="text",CONTROL="control";static int chosen;static int get(String role){return chosen;}}',
            "cat/ttcuz/framework/Accent.java": "package cat.ttcuz.framework;import android.view.View;import android.content.res.ColorStateList;import com.bytedance.tux.icon.TuxIconView;class Accent {static java.util.Map<TuxIconView,Integer> tintSources=new java.util.WeakHashMap<>();static int sourced(int c){return c;}static boolean nativeArtworkView(View v){return false;}"
            + safety.method("Accent.java", "    static void repaintContrast")
            + "}",
            "cat/ttcuz/framework/NativeRead.java": "package cat.ttcuz.framework;class NativeRead {static Object field(Object o,String n){try{return o.getClass().getField(n).get(o);}catch(Exception e){return null;}}}",
            "cat/ttcuz/framework/UiContrast.java": (
                ROOT / "inject/java/cat/ttcuz/framework/UiContrast.java"
            ).read_text(encoding="utf-8"),
            "Test.java": "public class Test {public static void main(String[] a){cat.ttcuz.framework.ContrastTest.run();}}",
            "cat/ttcuz/framework/ContrastTest.java": """package cat.ttcuz.framework;import android.view.*;import android.widget.*;import android.graphics.drawable.*;import android.content.res.*;import com.bytedance.tux.icon.TuxIconView;public class ContrastTest {
public static class NativeDrawable {public Integer LJIIZILJ=0xff000000;public ColorStateList LJIIJJI;}static void check(boolean b,String s){if(!b)throw new AssertionError(s);}static TextView label(String s){TextView v=new TextView();v.text=s;return v;}
public static void run(){
ViewGroup panel=new ViewGroup();panel.bg=new ColorDrawable(0xff222222);
ViewGroup nativePlaylist=new ViewGroup();nativePlaylist.id=0x7f0a5ef9;nativePlaylist.bg=new ColorDrawable(0xff222222);TextView nativeTitle=label("Love Trend");nativeTitle.id=0x7f0a8586;nativePlaylist.add(nativeTitle);UiContrast.repaint(nativeTitle);check(nativeTitle.getCurrentTextColor()==0xffeeeeee,"separate native playlist title");TextView reusedId=label("Other card");reusedId.id=0x7f0a8586;panel.add(reusedId);check(UiContrast.colour(reusedId,0xff000000)==0xff000000,"playlist id scoped to native rail");
TextView playlist=label("Плейлист • Love Trend");panel.add(playlist);ColorStateList original=playlist.getTextColors();
UiContrast.repaint(playlist);check(playlist.getCurrentTextColor()==0xffeeeeee,"playlist contrast");UiContrast.repaint(playlist);check(playlist.writes==1,"no repeated text writes");
panel.bg=new ColorDrawable(0xffffffff);UiContrast.repaint(playlist);check(playlist.getTextColors()==original,"restore original state list on light panel");
panel.bg=new ColorDrawable(0xff222222);UiContrast.repaint(playlist);playlist.text="ordinary body";UiContrast.repaint(playlist);check(playlist.getTextColors()==original,"recycled label restored");
TextView repost=label("Репост подписчикам");panel.add(repost);check(UiContrast.colour(repost,0xff161823)==0xffeeeeee,"repost dark native neutral");check(UiContrast.colour(repost,0xfffe2c55)==0xfffe2c55,"accent unchanged");check(UiContrast.colour(repost,0x33000000)==0x33000000,"disabled alpha unchanged");check(UiContrast.colour(repost,0xffffffff)==0xffffffff,"white unchanged");
TextView stateful=label("Плейлист • States");panel.add(stateful);stateful.colours=new ColorStateList(new int[][]{{-1},{}},new int[]{0x33000000,0xff000000});UiContrast.repaint(stateful);check(stateful.colours.colours[0]==0x33000000 && stateful.colours.colours[1]==0xffeeeeee,"disabled state and alpha preserved");
AppearanceColors.chosen=0xff000000;check(UiContrast.colour(repost,0xff000000)==0xff000000,"explicit colour wins");AppearanceColors.chosen=0;
View media=new View();media.id=0x7f0a4208;panel.add(media);check(UiContrast.colour(media,0xff000000)==0xff000000,"media cannot qualify by id");
TextView body=label("Reply");panel.add(body);check(UiContrast.colour(body,0xff000000)==0xff000000,"message text untouched");
TuxIconView comment=new TuxIconView();comment.id=0x7f0a4208;panel.add(comment);UiContrast.repaintTint(comment,0xff000000);check(comment.colour==0xffeeeeee,"mention icon contrast");UiContrast.repaintTint(comment,0xff000000);check(comment.writes==1,"no repeated tint writes");panel.bg=new ColorDrawable(0xffffffff);UiContrast.repaintTint(comment,0xff000000);check(comment.colour==0xff000000,"tint restored on light panel");
ViewGroup menu=new ViewGroup();menu.bg=new ColorDrawable(0xff333333);menu.add(label("Ответить"));menu.add(label("Переслать"));TuxIconView icon=new TuxIconView();ViewGroup row=new ViewGroup();row.add(icon);menu.add(row);check(UiContrast.colour(icon,0xff000000)==0xffeeeeee,"message menu icon contrast");
TuxIconView detached=new TuxIconView();detached.id=0x7f0a401f;UiContrast.defer(detached,0xff000000);UiContrast.defer(detached,0xff000000);check(detached.listeners.size()==1 && detached.tasks.isEmpty(),"one attach callback waits for actual attachment");detached.LL=new NativeDrawable();menu.add(detached);detached.listeners.get(0).onViewAttachedToWindow(detached);detached.tasks.remove(0).run();check(detached.colour==0xffeeeeee,"late attachment corrected");
TuxIconView xml=new TuxIconView();xml.id=0x7f0a419d;xml.LL=new NativeDrawable();menu.add(xml);Accent.repaintContrast(xml);check(xml.colour==0xffeeeeee,"XML tint fallback");
TuxIconView stateIcon=new TuxIconView();stateIcon.id=0x7f0a419d;NativeDrawable stateArt=new NativeDrawable();stateArt.LJIIZILJ=null;stateArt.LJIIJJI=ColorStateList.valueOf(0xff000000);stateIcon.LL=stateArt;menu.add(stateIcon);Accent.repaintContrast(stateIcon);check(stateIcon.colour==0xffeeeeee,"native state-list icon tint");
TextView unknown=label("Плейлист • Unknown");check(UiContrast.colour(unknown,0xff000000)==0xff000000,"unknown background untouched");
ViewGroup chip=new ViewGroup();chip.bg=new ColorDrawable(0x22000000);menu.add(chip);chip.add(repost);check(UiContrast.colour(repost,0xff000000)==0xffeeeeee,"translucent chip over dark panel");
menu.bg=new ColorDrawable(0xffffffff);check(UiContrast.colour(repost,0xff000000)==0xff000000,"translucent chip over white panel");
}}""",
        }
        safety.SafetyRuntimeTest().run_java(sources)
