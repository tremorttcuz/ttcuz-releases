package cat.ttcuz.framework;

/** Generated with Google's MCU 0.4.0, Expressive/2025/phone, contrast 0. See docs/material-colors.json. */
final class MaterialAccents {

    static final int[] LIGHT = {
        0xFF6850A5,
        0xFF4D6645,
        0xFF376B21,
        0xFF00649C,
        0xFF7A546A,
        0xFF944271,
        0xFF006B5E,
        0xFF735C2F,
        0xFF805700,
        0xFF386B20,
        0xFF605B7E,
        0xFF6751A5,
        0xFF8D5000,
        0xFF4F5F7E,
        0xFF1C60A6,
        0xFF9D4146,
        0xFF3B6570,
        0xFF006977,
    };
    static final int[] DARK = {
        0xFFD4C3FF,
        0xFFBBCBB2,
        0xFFEDFFDF,
        0xFFB8DBFF,
        0xFFDEBECE,
        0xFFFFAFD7,
        0xFFE5FFF8,
        0xFFD9C4A0,
        0xFFFFBE4E,
        0xFFD9FFC0,
        0xFFC9C3DC,
        0xFFCFBDFF,
        0xFFFFC793,
        0xFFBEC6DC,
        0xFFA4C9FF,
        0xFFFFBBBB,
        0xFFB2CBD2,
        0xFFA0EFFF,
    };
}
