package cat.ttcuz.framework;

import android.graphics.*;
import android.view.*;
import java.lang.ref.WeakReference;
import java.util.*;

/** A native repost listener, with local placement. No fabricated upvote request. */
public final class Repost {

    static final String KEY = "repost_btn",
        POS = "repost_pos";
    private static final int TAG = 0x7e0c0334;
    private static final Map<View, WeakReference<State>> nativeSlots = new WeakHashMap<>();
    private static final Map<View, WeakReference<Object>> anchors = new WeakHashMap<>();

    private static final class State {

        WeakReference<Object> component;
        final WeakReference<View> source;
        WeakReference<Button> button = new WeakReference<>(null);
        WeakReference<View> fav = new WeakReference<>(null);
        int wanted;

        State(Object c, View v) {
            component = new WeakReference<>(c);
            source = new WeakReference<>(v);
            wanted = v.getVisibility();
        }
    }

    /** The repost button is retired: the native repost control is left exactly as TikTok draws it. */
    static boolean enabled() {
        return false;
    }

    static int position() {
        try {
            return Math.max(
                0,
                Math.min(2, AccountAppearance.prefs(Ttcuz.context()).getInt(POS, 2))
            );
        } catch (Throwable ignored) {
            return 2;
        }
    }

    public static void bind(Object component) {
        Object view = NativeRead.get(component, "getContentView");
        if (!(view instanceof View)) return;
        View root = (View) view;
        Object existing = root.getTag(TAG);
        State state = existing instanceof State ? (State) existing : null;
        if (state == null) {
            state = new State(component, root);
            root.setTag(TAG, state);
            synchronized (nativeSlots) {
                nativeSlots.put(root, new WeakReference<>(state));
            }
        }
        if (state.component.get() != component) {
            state.component = new WeakReference<>(component);
            state.wanted = root.getVisibility();
        }
        final State saved = state;
        root.post(() -> apply(saved));
    }

    public static void anchor(Object component) {
        Object view = NativeRead.get(component, "getContentView");
        if (!(view instanceof View)) return;
        synchronized (anchors) {
            anchors.put((View) view, new WeakReference<>(component));
        }
        reload();
    }

    static boolean visibility(View root, int wanted) {
        WeakReference<State> reference;
        synchronized (nativeSlots) {
            reference = nativeSlots.get(root);
        }
        State state = reference == null ? null : reference.get();
        if (state == null) return false;
        state.wanted = wanted;
        apply(state);
        return true;
    }

    static void reload() {
        List<WeakReference<State>> values;
        synchronized (nativeSlots) {
            values = new ArrayList<>(nativeSlots.values());
        }
        for (WeakReference<State> reference : values) {
            State state = reference.get();
            View view = state == null ? null : state.source.get();
            if (view != null) view.post(() -> apply(state));
        }
    }

    static boolean replacing(View view) {
        if (!enabled() || position() != 0) return false;
        synchronized (nativeSlots) {
            for (WeakReference<State> r : nativeSlots.values()) {
                State s = r.get();
                Button b = s == null ? null : s.button.get();
                if (
                    s != null &&
                    s.fav.get() == view &&
                    b != null &&
                    b.getVisibility() == View.VISIBLE
                ) return true;
            }
        }
        return false;
    }

    private static void apply(State state) {
        View source = state.source.get();
        Object component = state.component.get();
        if (source == null || component == null) return;
        Button button = state.button.get();
        boolean available =
            enabled() && NativeRead.field(component, "LLLLILI") instanceof View.OnClickListener;
        String aid = NativeRead.aid(NativeRead.get(NativeRead.item(component), "getAweme"));
        View favorite = null,
            avatar = null;
        List<Map.Entry<View, WeakReference<Object>>> entries;
        synchronized (anchors) {
            entries = new ArrayList<>(anchors.entrySet());
        }
        for (Map.Entry<View, WeakReference<Object>> e : entries) {
            Object c = e.getValue().get();
            if (
                c == null ||
                e.getKey() == null ||
                !aid.equals(NativeRead.aid(NativeRead.get(NativeRead.item(c), "getAweme")))
            ) continue;
            String name = c.getClass().getName();
            if (name.endsWith("VideoFavoriteAssem")) favorite = e.getKey();
            else if (name.endsWith("FeedAvatarDefaultAssem")) avatar = e.getKey();
        }
        if (
            aid.length() == 0 ||
            favorite == null ||
            !favorite.isShown() ||
            !source.isAttachedToWindow()
        ) available = false;
        if (available && button == null) {
            ViewGroup parent = container(favorite, source);
            if (parent == null) {
                Diary.note("repost: no compatible native container");
                available = false;
            } else try {
                button = new Button(source.getContext(), state);
                int size = dp(source, 48);
                ViewGroup.LayoutParams params;
                if (parent instanceof android.widget.FrameLayout) {
                    android.widget.FrameLayout.LayoutParams fp =
                        new android.widget.FrameLayout.LayoutParams(size, size);
                    fp.gravity = Gravity.TOP | Gravity.LEFT;
                    params = fp;
                } else {
                    params = (ViewGroup.LayoutParams) Class.forName(
                        "androidx.constraintlayout.widget.ConstraintLayout$LayoutParams"
                    )
                        .getConstructor(int.class, int.class)
                        .newInstance(size, size);
                    params.getClass().getField("leftToLeft").setInt(params, 0);
                    params.getClass().getField("topToTop").setInt(params, 0);
                }
                parent.addView(button, params);
                state.button = new WeakReference<>(button);
                final State saved = state;
                parent.addOnLayoutChangeListener((v, l, t, r, b, ol, ot, or, ob) -> place(saved));
            } catch (Throwable error) {
                Diary.note("repost placement: " + error);
                available = false;
            }
        }
        state.fav = new WeakReference<>(favorite);
        source.setVisibility(state.wanted);
        Object click = NativeRead.field(component, "LLLJIL");
        NativeRepostVisual.remember(component);
        if (button != null) button.refresh(component);
        if (click instanceof View && click != source) {
            View icon = (View) click;
            Object tag = icon.getTag(0x7e0c0335);
            int wanted = tag instanceof Integer ? (Integer) tag : icon.getVisibility();
            if (available) {
                icon.setTag(0x7e0c0335, wanted);
                icon.setVisibility(wanted == View.VISIBLE ? View.INVISIBLE : wanted);
            } else if (tag instanceof Integer) {
                icon.setVisibility(wanted);
                icon.setTag(0x7e0c0335, null);
            }
        }
        if (button != null) button.setVisibility(available ? View.VISIBLE : View.GONE);
        if (available) {
            button.anchor = new WeakReference<>(
                position() == 1 && avatar != null ? avatar : favorite
            );
            place(state);
        }
        FeedRail.refreshFavorite(favorite);
    }

    private static ViewGroup container(View anchor, View source) {
        android.view.ViewParent p = anchor.getParent();
        for (int i = 0; i < 8 && p instanceof View; i++) {
            View v = (View) p;
            if (
                (v instanceof android.widget.FrameLayout ||
                    v
                        .getClass()
                        .getName()
                        .equals("androidx.constraintlayout.widget.ConstraintLayout")) &&
                descendant(source, v)
            ) return (ViewGroup) v;
            p = v.getParent();
        }
        return null;
    }

    private static boolean descendant(View child, View parent) {
        android.view.ViewParent p = child.getParent();
        for (int i = 0; i < 16 && p instanceof View; i++) {
            if (p == parent) return true;
            p = p.getParent();
        }
        return false;
    }

    private static int dp(View view, int value) {
        return (int) (value * view.getResources().getDisplayMetrics().density + .5f);
    }

    private static void place(State state) {
        Button button = state.button.get();
        View anchor = button == null ? null : button.anchor.get();
        if (button == null || anchor == null || !(button.getParent() instanceof View)) return;
        View parent = (View) button.getParent();
        int[] a = new int[2],
            b = new int[2];
        anchor.getLocationOnScreen(a);
        parent.getLocationOnScreen(b);
        int size = dp(button, 48);
        float x = a[0] - b[0] + (anchor.getWidth() - size) / 2f,
            y = a[1] - b[1] + (anchor.getHeight() - size) / 2f;
        if (position() == 1) y = a[1] - b[1] - size - dp(button, 4);
        if (position() == 2) x = a[0] - b[0] - size - dp(button, 6);
        x = Math.max(0, Math.min(Math.max(0, parent.getWidth() - size), x));
        y = Math.max(0, Math.min(Math.max(0, parent.getHeight() - size), y));
        button.setTranslationX(x - button.getLeft());
        button.setTranslationY(y - button.getTop());
    }

    public static void textureChanged(View icon) {
        List<WeakReference<State>> values;
        synchronized (nativeSlots) {
            values = new ArrayList<>(nativeSlots.values());
        }
        for (WeakReference<State> r : values) {
            State state = r.get();
            Object c = state == null ? null : state.component.get();
            Button b = state == null ? null : state.button.get();
            if (b != null && NativeRead.field(c, "LLLJL") == icon) b.refresh(c);
        }
        NativeRepostVisual.changed();
    }

    private static final class Button extends android.widget.ImageView {

        final State state;
        WeakReference<View> anchor = new WeakReference<>(null);

        Button(android.content.Context c, State s) {
            super(c);
            state = s;
            setScaleType(ScaleType.FIT_CENTER);
            int pad = dp(this, 8);
            setPadding(pad, pad, pad, pad);
            setContentDescription(Text.REPOST);
            setOnClickListener(v -> {
                Object component = s.component.get();
                View source = s.source.get();
                Object handler = NativeRead.field(component, "LLLLILI");
                if (
                    component != null &&
                    source != null &&
                    source.isAttachedToWindow() &&
                    handler instanceof View.OnClickListener
                ) {
                    Object target = NativeRead.field(component, "LLLJIL");
                    if (target instanceof View) ((View.OnClickListener) handler).onClick(
                        (View) target
                    );
                    else Screen.say(Text.REPOST_NOT_READY);
                } else Screen.say(Text.REPOST_NOT_READY);
            });
            Motion.press(this);
        }

        void refresh(Object component) {
            setImageDrawable(NativeRepostVisual.icon(getContext(), component));
        }
    }

    static View preview(android.content.Context context) {
        View preview = new View(context) {
            final Paint paint = new Paint(3);
            final android.graphics.RectF panel = new android.graphics.RectF();
            final android.graphics.drawable.Drawable[] icons = {
                SettingsGlyph.make("group", 0xffffffff),
                SettingsGlyph.make("favorite", 0xffffffff),
                SettingsGlyph.make("chat", 0xffffffff),
                SettingsGlyph.make("star", 0xffffffff),
                SettingsGlyph.make("share", 0xffffffff),
            };
            android.graphics.drawable.Drawable repost;
            int generation = -1;

            protected void onMeasure(int w, int h) {
                setMeasuredDimension(MeasureSpec.getSize(w), dp(this, 300));
            }

            protected void onDraw(Canvas c) {
                int w = getWidth(),
                    h = getHeight(),
                    margin = dp(this, 8);
                panel.set(margin, margin, w - margin, h - margin);
                paint.setColor(0xff111111);
                c.drawRoundRect(panel, dp(this, 20), dp(this, 20), paint);
                int size = dp(this, 32),
                    target = dp(this, 48),
                    left = w - dp(this, 66),
                    top = dp(this, 68),
                    gap = dp(this, 42);
                for (int i = 0; i < icons.length; i++) if (
                    icons[i] != null && !(position() == 0 && i == 3)
                ) {
                    icons[i].setBounds(left, top + i * gap, left + size, top + i * gap + size);
                    icons[i].draw(c);
                }
                int x = left - dp(this, 8),
                    y = top + 3 * gap - dp(this, 8);
                if (position() == 1) y = top - target - dp(this, 12);
                if (position() == 2) x -= target + dp(this, 6);
                if (generation != NativeRepostVisual.generation()) {
                    repost = NativeRepostVisual.icon(getContext(), null);
                    generation = NativeRepostVisual.generation();
                }
                if (repost != null) {
                    int inset = dp(this, 8);
                    repost.setBounds(x + inset, y + inset, x + target - inset, y + target - inset);
                    repost.draw(c);
                }
                paint.setColor(0xffeeeeee);
                paint.setTextSize(dp(this, 14));
                c.drawText("@profile", dp(this, 24), h - dp(this, 38), paint);
                paint.setColor(0xffaaaaaa);
                paint.setTextSize(dp(this, 11));
                c.drawText("Предпросмотр", dp(this, 24), dp(this, 34), paint);
            }
        };
        NativeRepostVisual.watch(preview);
        return preview;
    }
}
