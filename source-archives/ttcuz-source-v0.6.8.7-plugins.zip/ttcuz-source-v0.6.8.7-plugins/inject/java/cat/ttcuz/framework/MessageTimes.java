package cat.ttcuz.framework;

import android.view.*;
import android.widget.TextView;
import java.lang.ref.WeakReference;
import java.util.*;

/** An overlay in reserved native bubble padding, from the server's actual timestamp. */
public final class MessageTimes {

    static final String KEY = "message_times";
    private static final int TAG = 0x7e0c0333;
    private static final Map<View, WeakReference<State>> rows = new WeakHashMap<>();

    private static final class State {

        final TextView label;
        int bottom;
        boolean valid;
        boolean left;

        State(TextView t, int b) {
            label = t;
            bottom = b;
        }
    }

    static boolean enabled() {
        return true;
    }

    public static void before(Object component) {
        Object content = bubble(component);
        if (!(content instanceof View)) return;
        View root = (View) content;
        Object old = root.getTag(TAG);
        if (old instanceof State) {
            State state = (State) old;
            state.valid = false;
            ((ViewGroup) root).getOverlay().remove(state.label);
            root.setPadding(
                root.getPaddingLeft(),
                root.getPaddingTop(),
                root.getPaddingRight(),
                state.bottom
            );
        }
    }

    static Object bubble(Object component) {
        Object root = NativeRead.field(component, "LLLILZ");
        if (root instanceof ViewGroup) return root;
        root = NativeRead.get(component, "getContentView");
        return root instanceof View ? root : NativeRead.get(component, "LJJIZ");
    }

    static boolean incoming(Object message) {
        String own = Account.liveId();
        long sender = NativeRead.number(NativeRead.get(message, "getSender"));
        return own != null && own.length() > 0 && sender > 0 && !Long.toString(sender).equals(own);
    }

    static long millis(long raw) {
        if (raw <= 0) return 0;
        long ms = raw > 100000000000000L ? raw / 1000 : raw < 100000000000L ? raw * 1000 : raw;
        return ms >= 946684800000L && ms <= System.currentTimeMillis() + 86400000L ? ms : 0;
    }

    public static void bind(Object component, Object model) {
        try {
            Object content = bubble(component);
            if (!(content instanceof ViewGroup)) return;
            ViewGroup root = (ViewGroup) content;
            Object info = NativeRead.get(model, "LLILZIL");
            Object message = NativeRead.field(NativeRead.field(info, "LIZ"), "LIZ");
            long ms = millis(NativeRead.number(NativeRead.get(message, "getCreatedAt")));
            Object previous = root.getTag(TAG);
            State state = previous instanceof State ? (State) previous : null;
            if (!enabled() || ms == 0) {
                if (state != null) {
                    state.valid = false;
                    root.getOverlay().remove(state.label);
                    root.setPadding(
                        root.getPaddingLeft(),
                        root.getPaddingTop(),
                        root.getPaddingRight(),
                        state.bottom
                    );
                }
                return;
            }
            if (state == null) {
                TextView label = new TextView(root.getContext());
                label.setTextSize(11);
                label.setTextColor(Skin.remembered(root.getContext()).text);
                label.setAlpha(.65f);
                Fonts.apply(label);
                state = new State(label, root.getPaddingBottom());
                root.setTag(TAG, state);
                final State fixed = state;
                root.addOnLayoutChangeListener((v, l, t, r, b, ol, ot, or, ob) -> layout(v, fixed));
                synchronized (rows) {
                    rows.put(root, new WeakReference<>(state));
                }
            }
            state.left = incoming(message);
            if (!state.valid) state.bottom = root.getPaddingBottom();
            state.valid = true;
            state.label.setText(
                new java.text.SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(new Date(ms))
            );
            int height = (int) Math.ceil(20 * root.getResources().getDisplayMetrics().density);
            root.setPadding(
                root.getPaddingLeft(),
                root.getPaddingTop(),
                root.getPaddingRight(),
                state.bottom + height
            );
            root.getOverlay().add(state.label);
            layout(root, state);
        } catch (Throwable error) {
            Diary.note("message timestamp: " + error);
        }
    }

    private static void layout(View root, State state) {
        int width = Math.max(0, root.getWidth() - root.getPaddingLeft() - root.getPaddingRight());
        state.label.measure(
            View.MeasureSpec.makeMeasureSpec(width, View.MeasureSpec.AT_MOST),
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        );
        int w = state.label.getMeasuredWidth(),
            h = state.label.getMeasuredHeight(),
            right = root.getWidth() - root.getPaddingRight();
        int l, r;
        if (state.left && root instanceof ViewGroup) {
            l = Math.max(root.getPaddingLeft(), Math.min(contentLeft((ViewGroup) root), right - w));
            r = l + w;
        } else {
            r = right;
            l = Math.max(root.getPaddingLeft(), right - w);
        }
        state.label.layout(
            l,
            Math.max(0, root.getHeight() - state.bottom - h),
            r,
            root.getHeight() - state.bottom
        );
    }

    /** Left edge of the message itself (the biggest thing in the row), so the time sits under it and not under the avatar. */
    private static int contentLeft(ViewGroup root) {
        int left = 0;
        View node = root;
        for (int depth = 0; depth < 4 && node instanceof ViewGroup; depth++) {
            ViewGroup group = (ViewGroup) node;
            View best = null;
            int area = 0;
            for (int i = 0; i < group.getChildCount(); i++) {
                View child = group.getChildAt(i);
                if (child.getVisibility() != View.VISIBLE || child == null) continue;
                int size = child.getWidth() * child.getHeight();
                if (size > area) {
                    area = size;
                    best = child;
                }
            }
            if (best == null) break;
            left += best.getLeft();
            node = best;
        }
        return Math.max(root.getPaddingLeft(), left);
    }

    static void reload() {
        List<View> roots;
        synchronized (rows) {
            roots = new ArrayList<>(rows.keySet());
        }
        for (View root : roots)
            if (root != null) root.post(() -> {
                Object old = root.getTag(TAG);
                if (old instanceof State) {
                    State s = (State) old;
                    if (!enabled() || !s.valid) {
                        ((ViewGroup) root).getOverlay().remove(s.label);
                        root.setPadding(
                            root.getPaddingLeft(),
                            root.getPaddingTop(),
                            root.getPaddingRight(),
                            s.bottom
                        );
                    } else {
                        root.setPadding(
                            root.getPaddingLeft(),
                            root.getPaddingTop(),
                            root.getPaddingRight(),
                            s.bottom +
                                (int) Math.ceil(
                                    20 * root.getResources().getDisplayMetrics().density
                                )
                        );
                        ((ViewGroup) root).getOverlay().add(s.label);
                        layout(root, s);
                    }
                }
            });
    }
}
