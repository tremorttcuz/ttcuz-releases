package cat.ttcuz.framework;

import android.content.Context;
import java.util.*;

/** Public friend UIDs, scoped to the signed-in account. Never removes native members. */
public final class PinnedFriends {

    static final String KEY = "friends_pinned";
    static final int LIMIT = 20;
    private static final LinkedHashMap<String, String> candidates = new LinkedHashMap<>();
    private static volatile List<String> pins;
    private static final List<java.lang.ref.WeakReference<android.widget.LinearLayout>> watching =
        new ArrayList<>();
    private static final int REFRESH = 0x7e0c0351;
    private static final Map<String, String> avatars = new LinkedHashMap<>();

    static synchronized void reload() {
        pins = null;
        candidates.clear();
        avatars.clear();
    }

    static List<String> pins() {
        List<String> result = pins;
        if (result != null) return result;
        String raw = "";
        try {
            raw = AccountAppearance.prefs(Ttcuz.context()).getString(KEY, "");
        } catch (Throwable ignored) {}
        result = parse(raw);
        if (Ttcuz.context() != null) pins = result;
        return result;
    }

    static List<String> parse(String raw) {
        List<String> out = new ArrayList<>();
        if (raw == null || raw.length() > 4096) return out;
        for (String uid : raw.split("\n"))
            if (uid.matches("[0-9]{1,24}") && !out.contains(uid) && out.size() < LIMIT) out.add(
                uid
            );
        return Collections.unmodifiableList(out);
    }

    static void save(List<String> values) {
        StringBuilder raw = new StringBuilder();
        for (String uid : values) raw.append(uid).append('\n');
        AccountAppearance.prefs(Ttcuz.context()).edit().putString(KEY, raw.toString()).apply();
        pins = null;
    }

    public static List getUserList(Object response) {
        Object original = NativeRead.get(response, "getUserList");
        if (!(original instanceof List)) return null;
        List values = (List) original;
        observe(values);
        return order(values, pins());
    }

    static synchronized void observe(List values) {
        int count = 0;
        for (Object user : values) {
            if (++count > 512) break;
            String uid = NativeRead.uid(user);
            if (!uid.matches("[0-9]{1,24}")) continue;
            String name = NativeRead.string(NativeRead.get(user, "getNickname"));
            String handle = NativeRead.string(NativeRead.get(user, "getUniqueId"));
            String label =
                (name.length() == 0 ? uid : name) + (handle.length() == 0 ? "" : " · @" + handle);
            candidates.put(uid, label);
            Object avatar = NativeRead.get(user, "getAvatarThumb");
            if (avatar == null) avatar = NativeRead.get(user, "getAvatarMedium");
            Object urls = NativeRead.get(avatar, "getUrlList");
            if (urls instanceof List && !((List) urls).isEmpty()) avatars.put(
                uid,
                String.valueOf(((List) urls).get(0))
            );
            if (candidates.size() > 512) {
                String oldest = candidates.keySet().iterator().next();
                candidates.remove(oldest);
                avatars.remove(oldest);
            }
        }
        notifyViews();
    }

    private static void notifyViews() {
        java.util.Iterator<java.lang.ref.WeakReference<android.widget.LinearLayout>> iterator =
            watching.iterator();
        while (iterator.hasNext()) {
            android.widget.LinearLayout list = iterator.next().get();
            if (list == null) {
                iterator.remove();
                continue;
            }
            list.removeCallbacks(update);
            list.post(update);
        }
    }

    private static final Runnable update = () -> {
        List<java.lang.ref.WeakReference<android.widget.LinearLayout>> views;
        synchronized (PinnedFriends.class) {
            views = new ArrayList<>(watching);
        }
        for (java.lang.ref.WeakReference<android.widget.LinearLayout> ref : views) {
            android.widget.LinearLayout list = ref.get();
            if (list != null && list.isAttachedToWindow()) {
                Object callback = list.getTag(REFRESH);
                if (callback instanceof Runnable) ((Runnable) callback).run();
            }
        }
    };

    static List order(List values, List<String> pinned) {
        if (pinned.isEmpty() || values.size() > 10000) return values;
        List result = new ArrayList(values.size());
        Set<Integer> used = new HashSet<>();
        for (String uid : pinned)
            for (int i = 0; i < values.size(); i++) if (
                !used.contains(i) && uid.equals(NativeRead.uid(values.get(i)))
            ) {
                result.add(values.get(i));
                used.add(i);
            }
        for (int i = 0; i < values.size(); i++) if (!used.contains(i)) result.add(values.get(i));
        boolean changed = false;
        for (int i = 0; i < values.size(); i++) if (values.get(i) != result.get(i)) {
            changed = true;
            break;
        }
        return changed ? result : values;
    }

    static void show(Context context) {
        Panel panel = Panel.with(context, Skin.remembered(context), Text.PINNED_FRIENDS);
        android.widget.EditText search = panel.field(Text.SEARCH);
        android.widget.LinearLayout list = new android.widget.LinearLayout(context);
        list.setOrientation(1);
        panel.view(list);
        Runnable refresh = () -> render(context, list, search.getText().toString());
        search.addTextChangedListener(
            new android.text.TextWatcher() {
                public void beforeTextChanged(CharSequence s, int st, int c, int a) {}

                public void onTextChanged(CharSequence s, int st, int before, int count) {
                    refresh.run();
                }

                public void afterTextChanged(android.text.Editable e) {}
            }
        );
        list.setTag(REFRESH, refresh);
        synchronized (PinnedFriends.class) {
            watching.add(new java.lang.ref.WeakReference<>(list));
        }
        refresh.run();
        SocialLibrary.refresh(() -> {
            if (list.isAttachedToWindow()) refresh.run();
        });
        panel.quiet(Text.CLOSE, null).show();
    }

    private static void render(Context context, android.widget.LinearLayout list, String query) {
        list.removeAllViews();
        String q = query.trim().toLowerCase(Locale.ROOT);
        Map<String, String> all;
        synchronized (PinnedFriends.class) {
            all = new LinkedHashMap<>(candidates);
        }
        List<String> saved = pins();
        if (!saved.isEmpty()) label(context, list, Text.PINNED_FRIENDS, null);
        for (String uid : saved) {
            String name = all.containsKey(uid) ? all.get(uid) : uid;
            if (!name.toLowerCase(Locale.ROOT).contains(q) && !uid.contains(q)) continue;
            friendRow(context, list, uid, name, () ->
                new ModDialog.Builder(context)
                    .setItems(new String[] { Text.MOVE_UP, Text.MOVE_DOWN, Text.UNPIN }, (d, i) -> {
                        List<String> next = new ArrayList<>(pins());
                        int at = next.indexOf(uid);
                        if (at < 0) return;
                        if (i == 2) next.remove(uid);
                        else {
                            int to = at + (i == 0 ? -1 : 1);
                            if (to >= 0 && to < next.size()) Collections.swap(next, at, to);
                        }
                        save(next);
                        render(context, list, query);
                    })
                    .show()
            );
        }
        int shown = 0;
        for (Map.Entry<String, String> e : all.entrySet()) {
            if (
                saved.contains(e.getKey()) ||
                (!e.getValue().toLowerCase(Locale.ROOT).contains(q) && !e.getKey().contains(q))
            ) continue;
            if (shown++ == 0) label(context, list, Text.FRIEND_CANDIDATES, null);
            friendRow(context, list, e.getKey(), e.getValue(), () -> {
                List<String> next = new ArrayList<>(pins());
                if (next.size() >= LIMIT) {
                    Screen.say(Text.PIN_LIMIT);
                    return;
                }
                next.add(e.getKey());
                save(next);
                render(context, list, query);
            });
            if (shown >= 60) break;
        }
        if (all.isEmpty()) label(context, list, Text.FRIENDS_LOAD_HINT, null);
        else if (shown == 0 && saved.isEmpty()) label(context, list, Text.NOTHING_FOUND, null);
    }

    private static void friendRow(
        Context c,
        android.widget.LinearLayout list,
        String uid,
        String name,
        Runnable action
    ) {
        float density = c.getResources().getDisplayMetrics().density;
        android.widget.LinearLayout row = new android.widget.LinearLayout(c);
        row.setGravity(android.view.Gravity.CENTER_VERTICAL);
        int size = Math.round(36 * density),
            pad = Math.round(10 * density);
        row.setPadding(pad, pad, pad, pad);
        android.widget.ImageView avatar = new android.widget.ImageView(c);
        avatar.setScaleType(android.widget.ImageView.ScaleType.CENTER_CROP);
        android.graphics.drawable.GradientDrawable back =
            new android.graphics.drawable.GradientDrawable();
        back.setShape(android.graphics.drawable.GradientDrawable.OVAL);
        back.setColor(Skin.remembered(c).muted());
        avatar.setBackground(back);
        avatar.setClipToOutline(true);
        row.addView(avatar, new android.widget.LinearLayout.LayoutParams(size, size));
        String url;
        synchronized (PinnedFriends.class) {
            url = avatars.get(uid);
        }
        FriendAvatars.bind(avatar, url);
        android.widget.TextView text = new android.widget.TextView(c);
        text.setText(name);
        text.setTextSize(15);
        text.setTextColor(Skin.remembered(c).text);
        text.setPadding(pad, 0, 0, 0);
        Fonts.apply(text);
        row.addView(text, new android.widget.LinearLayout.LayoutParams(0, -2, 1));
        row.setOnClickListener(v -> action.run());
        Motion.press(row);
        list.addView(row);
    }

    private static void label(
        Context context,
        android.widget.LinearLayout list,
        String label,
        Runnable action
    ) {
        android.widget.TextView text = new android.widget.TextView(context);
        text.setText(label);
        text.setTextColor(Skin.remembered(context).text);
        text.setTextSize(15);
        float dp = context.getResources().getDisplayMetrics().density;
        text.setPadding(
            Math.round(12 * dp),
            Math.round(10 * dp),
            Math.round(12 * dp),
            Math.round(10 * dp)
        );
        text.setMinHeight(Math.round(48 * dp));
        Fonts.apply(text);
        if (action != null) {
            text.setOnClickListener(v -> action.run());
            Motion.press(text);
        }
        list.addView(text);
    }
}
