package cat.ttcuz.framework;

/** One success notice after actual server verification and restoration of the bio. */
final class VerificationNotice {

    static void success() {
        new android.os.Handler(android.os.Looper.getMainLooper()).post(() -> {
            Screen.say("Профиль подтверждён");
            try {
                android.content.Context c = Ttcuz.context();
                if (c == null) return;
                android.app.NotificationManager manager =
                    (android.app.NotificationManager) c.getSystemService(
                        android.content.Context.NOTIFICATION_SERVICE
                    );
                if (manager == null) return;
                String channel = "ttcuz_profile";
                android.app.Notification.Builder b;
                if (android.os.Build.VERSION.SDK_INT >= 26) {
                    android.app.NotificationChannel nc = new android.app.NotificationChannel(
                        channel,
                        "Профиль ttcuz",
                        android.app.NotificationManager.IMPORTANCE_DEFAULT
                    );
                    nc.setSound(null, null);
                    manager.createNotificationChannel(nc);
                    b = new android.app.Notification.Builder(c, channel);
                } else b = new android.app.Notification.Builder(c);
                b.setSmallIcon(android.R.drawable.stat_sys_download_done)
                    .setContentTitle("Профиль подтверждён")
                    .setContentText("Исходное описание восстановлено")
                    .setAutoCancel(true);
                manager.notify(0x7e0401, b.build());
            } catch (Throwable error) {
                Diary.note("verification notice: " + error);
            }
        });
    }
}
