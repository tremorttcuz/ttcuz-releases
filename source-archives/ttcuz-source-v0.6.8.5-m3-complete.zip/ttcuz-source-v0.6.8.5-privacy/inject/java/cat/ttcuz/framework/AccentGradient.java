package cat.ttcuz.framework;

import android.content.SharedPreferences;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Shader;
import android.graphics.drawable.GradientDrawable;

/** Static two-colour accents. Each owner keeps its shader until bounds or colours change. */
final class AccentGradient {
    private static final String ON = "accent_gradient_on", COLOUR = "accent_gradient_colour",
        MIX = "accent_gradient_mix";
    private static volatile State state;

    private static final class State {
        final boolean on;
        final int colour, mix;
        State(SharedPreferences p) {
            boolean enabled = false;
            int second = 0xFF006A6A, amount = 100;
            try {
                enabled = p.getBoolean(ON, false);
                second = p.getInt(COLOUR, second);
                amount = p.getInt(MIX, amount);
            } catch (ClassCastException ignored) {}
            on = enabled;
            colour = second | 0xFF000000;
            mix = Math.max(0, Math.min(100, amount));
        }
    }

    private static State state() {
        State known = state;
        if (known == null && Ttcuz.context() != null) {
            known = new State(AccountAppearance.prefs(Ttcuz.context()));
            state = known;
        }
        return known;
    }

    static boolean enabled() { State s = state(); return s != null && s.on; }
    static int colour() { State s = state(); return s == null ? 0xFF006A6A : s.colour; }
    static int mix() { State s = state(); return s == null ? 100 : s.mix; }
    static int end() { return Expressive.mix(Accent.colour(), colour(), mix() / 100f); }
    static int surface() { return enabled() ? Expressive.mix(Accent.colour(), end(), .5f) : Accent.colour(); }
    static void reload() { state = null; }
    static void set(boolean on, int colour, int mix) {
        if (Ttcuz.context() == null) return;
        AccountAppearance.prefs(Ttcuz.context()).edit().putBoolean(ON, on)
            .putInt(COLOUR, colour | 0xFF000000).putInt(MIX, Math.max(0, Math.min(100, mix))).apply();
        reload();
        Accent.set(Accent.colour());
    }

    static void shape(GradientDrawable shape, int solid) {
        if (enabled() && (solid & 0xFFFFFF) == (Accent.colour() & 0xFFFFFF)) {
            int alpha = solid & 0xFF000000;
            shape.setOrientation(GradientDrawable.Orientation.TL_BR);
            shape.setColors(new int[] { solid, alpha | (end() & 0xFFFFFF) });
        } else shape.setColor(solid);
    }

    static final class Fill {
        private int first, last;
        private float width, height;
        private Shader shader;
        void apply(Paint paint, float w, float h, int solid) {
            if (!enabled()) { paint.setShader(null); return; }
            int target = (solid & 0xFFFFFF) == (Accent.colour() & 0xFFFFFF)
                ? (solid & 0xFF000000) | (end() & 0xFFFFFF)
                : Expressive.mix(solid, end(), .18f);
            if (shader == null || first != solid || last != target || width != w || height != h) {
                first = solid; last = target; width = w; height = h;
                shader = new LinearGradient(0, 0, Math.max(1, w), Math.max(1, h),
                    first, last, Shader.TileMode.CLAMP);
            }
            paint.setShader(shader);
        }
    }
}
