package cat.ttcuz.framework;

import android.content.Context;
import android.content.SharedPreferences;
import java.io.File;

/** Appearance is owned by a UID, never by the device or mutable username. */
public final class AccountAppearance {

    private static volatile String selected;
    private static volatile long revision;

    private AccountAppearance() {}

    static String scope(Context context) {
        String value = selected;
        if (value != null) return value;
        String saved = context.getSharedPreferences(Ttcuz.PREFS, 0).getString(Account.KEY_ID, "");
        return valid(saved) ? saved : "guest";
    }

    private static boolean valid(String uid) {
        return uid != null && uid.matches("[0-9]{1,24}");
    }

    static synchronized void select(String uid) {
        String next = valid(uid) ? uid : "guest";
        if (next.equals(selected)) return;
        final long change = ++revision;
        Context context = Ttcuz.context();
        if (context == null) {
            selected = next;
            return;
        }
        if (
            selected == null &&
            valid(context.getSharedPreferences(Ttcuz.PREFS, 0).getString(Account.KEY_ID, ""))
        ) prefs(context);
        selected = next;
        prefs(context);
        TtcuzProfileSync.accountChanged(uid);
        Accent.reload();
        AppearanceColors.reload();
        Fonts.reload();
        Themes.forget();
        LikeColors.reload();
        ProfileStyle.reload();
        FeedRail.reloadSettings();
        FeedBlacklist.reload();
        PlayerTools.accountChanged();
        VideoActions.accountChanged();
        PinnedFriends.reload();
        ProfileLayout.reload();
        MessageTimes.reload();
        ModNotifications.reload();
        Repost.reload();
        new android.os.Handler(android.os.Looper.getMainLooper()).post(() -> {
            if (change != revision) return;
            Themes.repaintVisible();
            Badge.refreshProfiles();
            Accent.refreshLikeViews();
            android.app.Activity activity = Screen.now();
            if (activity instanceof SettingsActivity) (
                (SettingsActivity) activity
            ).accountAppearanceChanged();
        });
    }

    public static SharedPreferences prefs(Context context) {
        String uid = scope(context);
        SharedPreferences own = context.getSharedPreferences("ttcuz_appearance_" + uid, 0);
        if (!own.getBoolean("_initialized", false)) synchronized (AccountAppearance.class) {
            if (!own.getBoolean("_initialized", false)) {
                SharedPreferences legacy = context.getSharedPreferences(Ttcuz.PREFS, 0);
                SharedPreferences.Editor edit = own.edit();
                // Import once, into the first identified account only.
                if (!uid.equals("guest") && !legacy.getBoolean("appearance_uid_migrated", false)) {
                    for (java.util.Map.Entry<String, ?> entry : legacy.getAll().entrySet())
                        if (appearanceKey(entry.getKey())) copy(
                            edit,
                            entry.getKey(),
                            entry.getValue()
                        );
                    for (String path : new String[] {
                        "ttcuz/profile-badge.png",
                        "ttcuz/profile-badge-source.png",
                        "ttcuz/font",
                        "ttcuz/nickname-font",
                        "ttcuz/emoji-emoji_file",
                    }) {
                        String name = path.endsWith("emoji-emoji_file")
                            ? "emoji-custom"
                            : new File(path).getName();
                        File from = new File(context.getFilesDir(), path),
                            to = new File(
                                context.getFilesDir(),
                                "ttcuz/accounts/" + uid + "/" + name
                            );
                        if (from.isFile() && !to.exists()) try {
                            to.getParentFile().mkdirs();
                            java.io.InputStream in = new java.io.FileInputStream(from);
                            java.io.OutputStream out = new java.io.FileOutputStream(to);
                            try {
                                byte[] block = new byte[16384];
                                int n;
                                while ((n = in.read(block)) != -1) out.write(block, 0, n);
                            } finally {
                                in.close();
                                out.close();
                            }
                        } catch (Throwable error) {
                            Diary.note("appearance migration: " + error);
                        }
                    }
                    legacy.edit().putBoolean("appearance_uid_migrated", true).apply();
                }
                edit.putBoolean("_initialized", true).apply();
            }
        }
        return own;
    }

    static boolean appearanceKey(String key) {
        return (
            key.equals("streak_send_minute") ||
            key.startsWith("notify_") ||
            key.startsWith("friends_") ||
            key.equals("message_times") ||
            key.startsWith("repost_") ||
            key.equals("profile_layout") ||
            key.startsWith("rail_") ||
            key.startsWith("player_") ||
            key.startsWith("dl_") ||
            key.equals("frame_quality") ||
            key.startsWith("feed_blocked_") ||
            key.equals("accent") ||
            key.equals("accent_custom") ||
            key.startsWith("accent_gradient_") ||
            key.startsWith("appearance_color_") ||
            key.startsWith("theme_") ||
            key.equals("font") ||
            key.equals("font_emoji") ||
            key.equals("like_color") ||
            key.equals("comment_like_color") ||
            key.startsWith("profile_gradient_") ||
            key.startsWith("profile_nickname_") ||
            key.startsWith("profile_badge_") ||
            key.startsWith("profile_crown_") ||
            key.startsWith("profile_share") ||
            key.equals("profile_display_name")
        );
    }

    private static void copy(SharedPreferences.Editor edit, String key, Object value) {
        if (value instanceof String) edit.putString(key, (String) value);
        else if (value instanceof Boolean) edit.putBoolean(key, (Boolean) value);
        else if (value instanceof Integer) edit.putInt(key, (Integer) value);
        else if (value instanceof Long) edit.putLong(key, (Long) value);
        else if (value instanceof Float) edit.putFloat(key, (Float) value);
    }

    static File file(Context context, String name) {
        return new File(context.getFilesDir(), "ttcuz/accounts/" + scope(context) + "/" + name);
    }
}
