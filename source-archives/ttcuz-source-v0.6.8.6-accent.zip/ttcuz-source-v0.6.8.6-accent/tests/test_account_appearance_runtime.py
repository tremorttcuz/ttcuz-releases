"""Execute actual account hooks, migration and account-scoped appearance storage."""

import pathlib, shutil, subprocess, tempfile, unittest

ROOT = pathlib.Path(__file__).resolve().parents[1]
STUBS = {
    "cat/ttcuz/framework/FeedRail.java": "package cat.ttcuz.framework;class FeedRail{static void reloadSettings(){}}",
    "android/content/SharedPreferences.java": """package android.content;public interface SharedPreferences {java.util.Map<String,?> getAll();String getString(String k,String d);boolean getBoolean(String k,boolean d);int getInt(String k,int d);boolean contains(String k);Editor edit();interface Editor {Editor putString(String k,String v);Editor putBoolean(String k,boolean v);Editor putInt(String k,int v);Editor putLong(String k,long v);Editor putFloat(String k,float v);Editor remove(String k);void apply();}}""",
    "android/content/Context.java": """package android.content;public class Context {public static int MODE_PRIVATE=0;public java.io.File files;public java.util.Map<String,Memory> stores=new java.util.HashMap<>();public java.io.File getFilesDir(){return files;}public SharedPreferences getSharedPreferences(String n,int m){Memory p=stores.get(n);if(p==null){p=new Memory();stores.put(n,p);}return p;}
 public static class Memory implements SharedPreferences {java.util.Map<String,Object> values=new java.util.HashMap<>();public java.util.Map<String,?> getAll(){return new java.util.HashMap<>(values);}public String getString(String k,String d){return values.containsKey(k)?(String)values.get(k):d;}public boolean getBoolean(String k,boolean d){return values.containsKey(k)?(Boolean)values.get(k):d;}public int getInt(String k,int d){return values.containsKey(k)?(Integer)values.get(k):d;}public boolean contains(String k){return values.containsKey(k);}public Editor edit(){return new Editor(){java.util.Map<String,Object> writes=new java.util.HashMap<>();public Editor putString(String k,String v){writes.put(k,v);return this;}public Editor putBoolean(String k,boolean v){writes.put(k,v);return this;}public Editor putInt(String k,int v){writes.put(k,v);return this;}public Editor putLong(String k,long v){writes.put(k,v);return this;}public Editor putFloat(String k,float v){writes.put(k,v);return this;}public Editor remove(String k){writes.put(k,null);return this;}public void apply(){for(java.util.Map.Entry<String,Object> e:writes.entrySet())if(e.getValue()==null)values.remove(e.getKey());else values.put(e.getKey(),e.getValue());}};}}}""",
    "android/os/Handler.java": "package android.os;public class Handler {public Handler(Looper l){}public static boolean queued;public static java.util.List<Runnable> jobs=new java.util.ArrayList<>();public void post(Runnable r){if(queued)jobs.add(r);else r.run();}}",
    "android/os/Looper.java": "package android.os;public class Looper {public static Looper getMainLooper(){return null;}}",
    "android/os/SystemClock.java": "package android.os;public class SystemClock {public static long uptimeMillis(){return 100000;}}",
    "android/app/Activity.java": "package android.app;public class Activity {}",
    "cat/ttcuz/framework/SettingsActivity.java": "package cat.ttcuz.framework;class SettingsActivity extends android.app.Activity {void accountAppearanceChanged(){}}",
    "cat/ttcuz/framework/Screen.java": "package cat.ttcuz.framework;class Screen {static android.app.Activity now(){return null;}}",
    "cat/ttcuz/framework/Ttcuz.java": 'package cat.ttcuz.framework;class Ttcuz {static String PREFS="mod";static android.content.Context ctx;static android.content.Context context(){return ctx;}}',
    "cat/ttcuz/framework/AppearanceColors.java": "package cat.ttcuz.framework;class AppearanceColors {static void reload(){}}",
    "cat/ttcuz/framework/Fonts.java": "package cat.ttcuz.framework;class Fonts {static void reload(){}}",
    "cat/ttcuz/framework/Themes.java": "package cat.ttcuz.framework;class Themes {static void forget(){}static void repaintVisible(){}}",
    "cat/ttcuz/framework/Accent.java": "package cat.ttcuz.framework;class Accent {static void refreshLikeViews(){}}",
    "cat/ttcuz/framework/LikeColors.java": "package cat.ttcuz.framework;class LikeColors {static void reload(){}}",
    "cat/ttcuz/framework/Badge.java": "package cat.ttcuz.framework;class Badge {static int refreshed;static void refreshProfiles(){refreshed++;}}",
    "cat/ttcuz/framework/Diary.java": "package cat.ttcuz.framework;class Diary {static void note(String value){throw new AssertionError(value);}}",
    "cat/ttcuz/framework/BioProof.java": "package cat.ttcuz.framework;class BioProof {static void recover(){}}",
    "cat/ttcuz/framework/Avatars.java": "package cat.ttcuz.framework;class Avatars {static void rememberCurrent(com.ss.android.ugc.aweme.profile.model.User u){}}",
    "cat/ttcuz/framework/RecentProfiles.java": "package cat.ttcuz.framework;class RecentProfiles {static void remember(String u,String h){}}",
    "cat/ttcuz/framework/ProfilePreview.java": "package cat.ttcuz.framework;class ProfilePreview {static void accountUpdated(){}}",
    "cat/ttcuz/framework/TtcuzProfileSync.java": "package cat.ttcuz.framework;class TtcuzProfileSync {static class Metadata {String displayName;}static Metadata remote;static Metadata cached(String uid){return remote;}static void accountChanged(String uid){}static void publishOwn(){}static void autoVerifyOwn(){}}",
    "com/ss/android/ugc/aweme/profile/model/User.java": "package com.ss.android.ugc.aweme.profile.model;public class User {public String uid,name,handle;public User(String u,String n,String h){uid=u;name=n;handle=h;}public String getUid(){return uid;}public String getNickname(){return name;}public String getUniqueId(){return handle;}}",
    "com/ss/android/ugc/profile/platform/base/data/UserProfileInfo.java": "package com.ss.android.ugc.profile.platform.base.data;public class UserProfileInfo extends com.ss.android.ugc.aweme.profile.model.User {public UserProfileInfo(String u,String n,String h){super(u,n,h);}}",
    "com/ss/android/ugc/aweme/IAccountUserService.java": "package com.ss.android.ugc.aweme;public interface IAccountUserService {String getCurUserId();String getCurSecUserId();com.ss.android.ugc.aweme.profile.model.User getCurUser();}",
}
STUBS["cat/ttcuz/framework/Launcher.java"] = (
    "package cat.ttcuz.framework;class Launcher{static void followAccent(){}}"
)
STUBS["cat/ttcuz/framework/FeedRail.java"] = (
    "package cat.ttcuz.framework;class FeedRail{static void reloadSettings(){}}"
)
STUBS["cat/ttcuz/framework/FeedBlacklist.java"] = (
    "package cat.ttcuz.framework;class FeedBlacklist{static void reload(){}}"
)
STUBS["cat/ttcuz/framework/PlayerTools.java"] = (
    "package cat.ttcuz.framework;class PlayerTools{static void accountChanged(){} static void cancelSmooth(){}}"
)
STUBS["cat/ttcuz/framework/VideoActions.java"] = (
    "package cat.ttcuz.framework;class VideoActions{static void accountChanged(){} static void bindNative(Object c){} static void selected(Object c,Object p){}}"
)
STUBS["cat/ttcuz/framework/PinnedFriends.java"] = (
    "package cat.ttcuz.framework;class PinnedFriends{static void reload(){}}"
)
STUBS["cat/ttcuz/framework/ProfileLayout.java"] = (
    "package cat.ttcuz.framework;class ProfileLayout{static void reload(){}}"
)
STUBS["cat/ttcuz/framework/MessageTimes.java"] = (
    "package cat.ttcuz.framework;class MessageTimes{static void reload(){}}"
)
STUBS["cat/ttcuz/framework/ModNotifications.java"] = (
    "package cat.ttcuz.framework;class ModNotifications{static void reload(){}}"
)
STUBS["cat/ttcuz/framework/Repost.java"] = (
    "package cat.ttcuz.framework;class Repost{static void reload(){} static void anchor(Object c){} static boolean visibility(Object v,int value){return false;}static boolean replacing(Object v){return false;}}"
)

HARNESS = """package cat.ttcuz.framework;import android.content.*;import com.ss.android.ugc.aweme.profile.model.User;
public class AppearanceHarness {
 static void check(boolean value,String message){if(!value)throw new AssertionError(message);}
 static class Service implements com.ss.android.ugc.aweme.IAccountUserService {User user;Service(User u){user=u;}public String getCurUserId(){return user==null?"":user.uid;}public String getCurSecUserId(){return "sec";}public User getCurUser(){return user;}}
 public static void main(String[] args)throws Exception {
  Context ctx=new Context();ctx.files=new java.io.File(args[0]);Ttcuz.ctx=ctx;
  SharedPreferences legacy=ctx.getSharedPreferences("mod",0);
  legacy.edit().putString("account_id","111").putInt("accent",123).putBoolean("profile_gradient_on",true).putString("font","file").putString("profile_sync_token","secret").apply();
  java.io.File old=new java.io.File(ctx.files,"ttcuz/profile-badge.png");old.getParentFile().mkdirs();java.nio.file.Files.write(old.toPath(),new byte[]{1,2});
  Service a=new Service(new User("111","Lolipuzik1","lolipuzik1")),b=new Service(new User("222","Bob2","bob2"));
  Account.getCurUser(a);SharedPreferences one=AccountAppearance.prefs(ctx);
  check(one.getInt("accent",0)==123 && one.getBoolean("profile_gradient_on",false),"first account inherits legacy style once");
  check(Accent.colour()==123,"actual accent cache starts with first account");
  check(!one.contains("profile_sync_token"),"verification secrets stay out of appearance storage");
  check(AccountAppearance.file(ctx,"profile-badge.png").isFile(),"badge migrated into owner folder");
  one.edit().putString("profile_display_name","Lolipuzik").apply();
  check("Lolipuzik1".equals(ProfileStyle.displayName("111",Account.canonicalName("111","wrong"))),"example override removed; actual nickname preserved");
  Account.getCurUser(b);SharedPreferences two=AccountAppearance.prefs(ctx);
  check(two!=one && two.getInt("accent",0)==0 && !two.getBoolean("profile_gradient_on",false),"second account starts independently");
  check(!AccountAppearance.file(ctx,"profile-badge.png").exists(),"badge is not inherited by second account");
  check(Accent.colour()==99,"cached accent resets for second account");Accent.set(456);check("Bob2".equals(ProfileStyle.displayName("222","Bob2")),"legitimate nickname digits survive");
  Account.getCurUser(a);check(AccountAppearance.prefs(ctx).getInt("accent",0)==123 && Accent.colour()==123,"switch back restores actual first-account accent cache");
  Account.rememberProfile(new com.ss.android.ugc.profile.platform.base.data.UserProfileInfo("111","Wrong1","lolipuzik1"));
  check("Lolipuzik1".equals(Account.canonicalName("111","Wrong1")),"secondary profile model cannot replace authoritative nickname");
  check("Other7".equals(Account.canonicalName("999","Other7")),"another profile unchanged");
  Account.getCurUser(new Service(null));check("guest".equals(AccountAppearance.scope(ctx)) && !AccountAppearance.prefs(ctx).contains("accent"),"logout uses separate guest appearance");
  Account.getCurUser(b);check(AccountAppearance.prefs(ctx).getInt("accent",0)==456 && Accent.colour()==456,"second account actual accent restored after logout");
  check(!AccountAppearance.appearanceKey("account_id") && !AccountAppearance.appearanceKey("profile_preview_name"),"identity stays outside appearance");
  TtcuzProfileSync.remote=new TtcuzProfileSync.Metadata();TtcuzProfileSync.remote.displayName="Shared name";
  check("Shared name".equals(ProfileStyle.displayName("987654","Native name")),"remote shared name replaces only display text");
  TtcuzProfileSync.remote.displayName="";check("Native name".equals(ProfileStyle.displayName("987654","Native name")),"empty remote name falls back to native");
  android.os.Handler.queued=true;Badge.refreshed=0;
  AccountAppearance.select("111");AccountAppearance.select("222");AccountAppearance.select("111");
  android.os.Handler.jobs.get(0).run();check(Badge.refreshed==0,"stale account callback must be ignored");
  android.os.Handler.jobs.get(1).run();check(Badge.refreshed==0,"intermediate account callback must be ignored");
  android.os.Handler.jobs.get(2).run();check(Badge.refreshed==1,"only final account refreshes UI");
  System.out.println("two-account migration, identity and appearance checks passed");
 }
}"""


class AppearanceRuntimeTest(unittest.TestCase):
    @unittest.skipUnless(shutil.which("javac") and shutil.which("java"), "JDK required")
    def test_two_accounts_and_logout(self):
        with tempfile.TemporaryDirectory() as directory:
            work = pathlib.Path(directory)
            sources = dict(STUBS)
            accent = (ROOT / "inject/java/cat/ttcuz/framework/Accent.java").read_text(
                encoding="utf-8"
            )

            def method(signature):
                start = accent.index(signature)
                pos = accent.index("{", start)
                depth = 1
                end = pos + 1
                while depth:
                    if accent[end] == "{":
                        depth += 1
                    elif accent[end] == "}":
                        depth -= 1
                    end += 1
                return accent[start:end]

            sources["cat/ttcuz/framework/Accent.java"] = (
                'package cat.ttcuz.framework;import android.content.*;class Accent {static int cached;static final int BUILT_WITH=99;static final String KEY="accent";static void forget(){}static void refreshLikeViews(){}'
                + "".join(
                    method(sig)
                    for sig in (
                        "static void reload()",
                        "public static int colour()",
                        "public static void set(",
                        "private static SharedPreferences prefs()",
                    )
                )
                + "}"
            )
            for name in ("Account", "AccountAppearance"):
                sources["cat/ttcuz/framework/" + name + ".java"] = (
                    ROOT / ("inject/java/cat/ttcuz/framework/" + name + ".java")
                ).read_text(encoding="utf-8")
            profile = (ROOT / "inject/java/cat/ttcuz/framework/ProfileStyle.java").read_text(
                encoding="utf-8"
            )
            fragment = profile[
                profile.index("    static String displayName(") : profile.index(
                    "    static void setDisplayName("
                )
            ]
            sources["cat/ttcuz/framework/ProfileStyle.java"] = (
                "package cat.ttcuz.framework;import android.content.SharedPreferences;class ProfileStyle {static void reload(){}static SharedPreferences prefs(){return AccountAppearance.prefs(Ttcuz.context());}"
                + fragment
                + "}"
            )
            sources["cat/ttcuz/framework/AppearanceHarness.java"] = HARNESS
            for name, content in sources.items():
                target = work / name
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_text(content, encoding="utf-8")
            built = subprocess.run(
                ["javac", "-source", "8", "-target", "8", "-encoding", "UTF-8", "-d", str(work)]
                + [str(work / name) for name in sources],
                capture_output=True,
                text=True,
            )
            self.assertEqual(0, built.returncode, built.stderr)
            run = subprocess.run(
                [
                    "java",
                    "-cp",
                    str(work),
                    "cat.ttcuz.framework.AppearanceHarness",
                    str(work / "files"),
                ],
                capture_output=True,
                text=True,
            )
            self.assertEqual(0, run.returncode, run.stderr)
