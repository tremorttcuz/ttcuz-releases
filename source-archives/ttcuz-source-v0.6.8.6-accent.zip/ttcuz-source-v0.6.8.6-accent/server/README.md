# Сервер ttcuz

Основная реализация — Cloudflare Worker в `cloudflare/`.
Рабочий адрес: https://ttcuz.daniilsolovatulin.workers.dev.
Точка входа: `worker.mjs`; конфигурация: `wrangler.toml`.

| Модуль | Назначение |
| --- | --- |
| `profiles.mjs` | Профили, значки, каталог значков |
| `appearance.mjs` | Резервные копии оформления |
| `device.mjs` | Восстановление доступа устройства |
| `releases.mjs` | Проверка обновлений из `tremorttcuz/ttcuz-releases` |
| `crashes.mjs`, `discord.mjs` | Добровольные отчёты и уведомления |
| `plugins.mjs` | Сохранённая серверная подсистема плагинов |
| `migrations/` | Миграции D1 |
| `public/` | Статические файлы |

## Развёртывание

Рабочая база D1 — `ttcuz-profiles`, binding — `PROFILES`.
`schema.sql` описывает схему, `migrations/` — изменения существующей базы.
Проверяйте уже применённые миграции перед обновлением.

Для 0.6.8.2 предусмотрены `0009-appearance-backups.sql` и
`0010-nickname-fonts.sql`: приватные копии оформления и файлы шрифтов ника.
В рабочей базе эти две миграции уже применены. Новый экземпляр сервера
нужно создать по `schema.sql`, существующий — обновить миграциями.

```sh
cd server/cloudflare
npx wrangler deploy --dry-run
npx wrangler deploy
```

Секреты задаются через Wrangler и не хранятся в исходниках.
Настройка отчётов: [crash-reports.md](../docs/crash-reports.md).
Обновления: [releases.md](../docs/releases.md).
Профили: [profile-sync.md](../docs/profile-sync.md).

Python-сервис и legacy-инструменты сохранены отдельно;
они не заменяют production Worker. Инструкция:
[python-server.md](python-server.md).
